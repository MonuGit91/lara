/**
 * 
 */
/**
 * 
 */
module Strings {
}