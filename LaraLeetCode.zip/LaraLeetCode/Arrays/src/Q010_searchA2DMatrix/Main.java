package Q010_searchA2DMatrix;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		int mat[][] = { { 1, 3, 5, 7 }, { 10, 11, 16, 20 }, { 23, 30, 34, 60 } };
//		System.out.println(Solution.searchMatrix(mat, 13));
		
		int mat[][] = { { 1, 3, 5, 7 }, { 10, 11, 16, 20 }, { 23, 30, 34, 60 } };
		System.out.println(Solution.searchMatrix(mat, 3));
	}

}
