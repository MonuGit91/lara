package Q003_missingNumber;

public class Main {

	public static void main(String[] args) {
//		Solution obj = new Solution();
//		Q4a obj = new Solution1();
//		Q4b obj = new Solution2();
		Solution3 obj = new Solution3();
		
//    	int arr[] = {1, 3, 4, 2, 0, 6};
//    	System.out.println(obj.missingNumber(arr));
	
//		int arr[] = {5, 1, 3, 4, 2, 0, 6};
//		System.out.println(obj.missingNumber(arr));
    	
//    	int arr[] = {1};
//		System.out.println(obj.missingNumber(arr));
    	
//    	int arr[] = {1, 3, 4, 2, 0, 6};
//    	System.out.println(obj.missingNumber(arr));
		
		int arr[] = {1, 3, 4, 2, 0, 6, 5};
    	System.out.println(obj.missingNumber(arr));
	}

}
