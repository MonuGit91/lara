package Q002_sortColor;

import java.util.Arrays;

public class Solution2 {
	public void sortColors(int[] nums) {
        Arrays.sort(nums);
    }
}
