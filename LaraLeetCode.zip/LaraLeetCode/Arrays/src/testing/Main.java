package testing;

import java.util.*;
import java.util.Comparator;

public class Main {
	public static void main(String[] args) {
		int arr[] = {1, 3, 5, 7, 9};
		int a = Arrays.binarySearch(arr, 6);
		System.out.println(a);
	}

}
