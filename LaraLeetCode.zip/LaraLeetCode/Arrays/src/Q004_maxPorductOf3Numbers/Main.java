package Q004_maxPorductOf3Numbers;

public class Main {

	public static void main(String[] args) {
		Solution obj = new Solution();
		
		int arr[] = {10, 2, 4, 5, 20, 40};
		System.out.println(obj.maximumProduct(arr));
		
//		int arr[] = {-10, 2, -50, 4, 5, 20, 40};
//		System.out.println(obj.maximumProduct(arr));

	}

}
