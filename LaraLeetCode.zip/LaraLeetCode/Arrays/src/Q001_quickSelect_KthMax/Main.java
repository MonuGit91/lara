package Q001_quickSelect_KthMax;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Solution1 obj = new Solution1();
//		Solution1 obj = new Solution1();
//		Solution2 obj = new Solution2();
//		Solution3 obj = new Solution3();
//		Solution4 obj = new Solution4();
		
		int arr[] = { 2, 5, 1, 3, 8, 4, 6 };
		System.out.println(obj.findKthLargest(arr, 2));

//		int arr[] = { 1, 2, 3, 6, 2, 8, 9, 7 };
//		System.out.println(obj.findKthLargest(arr, 3));
//
//		int arr[] = { 2, 5, 3, 4, 10, 1, 12, 11, 9, 8, 6 };
//		System.out.println(obj.findKthLargest(arr, 2));
//
//		int arr[] = { 2, 10, 6, 7, 1, 4, 9, 5, 5 };
//		System.out.println(obj.findKthLargest(arr, 4));

	}
}
