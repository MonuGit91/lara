package Q007_nitherMaxNotMin;

public class Main {
	public static void main(String[] args) {
//		Solution obj = new Solution();
		Solution1 obj = new Solution1();
		
//		int arr[] = {3,2,1,4};
//		System.out.println(obj.findNonMinOrMax(arr));
		
//		int arr[] = {1,2};
//		System.out.println(obj.findNonMinOrMax(arr));
		
		int arr[] = {5,1,2,10,50,30,0};
		System.out.println(obj.findNonMinOrMax(arr));
	}
}
